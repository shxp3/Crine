package net.ccbluex.liquidbounce.ui.client.gui.clickgui

import net.minecraft.util.ResourceLocation

object IconManager {
    val removeIcon = ResourceLocation("crosssine/ui/clickgui/close.png")
    val back = ResourceLocation("crosssine/ui/clickgui/back.png")
    val search = ResourceLocation("crosssine/ui/clickgui/search.png")
    val settings = ResourceLocation("crosssine/ui/misc/settings.png")
}