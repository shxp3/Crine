package net.ccbluex.liquidbounce.ui.client.gui.clickgui

import net.ccbluex.liquidbounce.CrossSine
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.element.CategoryElement
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.element.SearchElement
import net.ccbluex.liquidbounce.ui.client.gui.colortheme.ClientTheme
import net.ccbluex.liquidbounce.ui.client.gui.GuiClientSettings
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.extensions.animSmooth
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.AnimationUtils
import net.ccbluex.liquidbounce.utils.MouseUtils.mouseWithinBounds
import net.ccbluex.liquidbounce.utils.geom.Rectangle
import net.ccbluex.liquidbounce.utils.render.EaseUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.ShaderUtil
import net.minecraft.client.gui.GuiScreen
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.util.ResourceLocation
import org.apache.commons.lang3.tuple.MutablePair
import org.lwjgl.input.Keyboard
import org.lwjgl.input.Mouse
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.io.IOException
import java.util.function.Consumer
import kotlin.math.abs

/**
 * @author inf (original java code)
 * @author pie (refactored)
 */
class ClickGui : GuiScreen() {
    private val categoryElements: MutableList<CategoryElement> = ArrayList()
    private var startYAnim = height / 2f
    private var endYAnim = height / 2f
    private var colorHoveredAnim = 0F
    private var speedHoveredAnim = 0F
    private var indexHoveredAnim = 0F
    private var searchElement: SearchElement? = null

    private val backgroundColor = Color(16, 16, 16, 255)
    private var stringWidth = 0F
    var windowXStart = 30f
    private var windowYStart = 30f
    private var windowXEnd = 500f
    private var windowYEnd = 400f
    private val windowWidth
        get() = abs(windowXEnd - windowXStart)
    private val windowHeight
        get() = abs(windowYEnd - windowYStart)
    private val minWindowWidth = 475f
    private val minWindowHeight = 350f

    private val searchXOffset = 10f
    private val searchYOffset = 30f

    var sideWidth = 120f
    private val categoryXOffset
        get() = sideWidth
    private val searchWidth
        get() = sideWidth - 10f
    private val searchHeight = 20f

    private val elementHeight = 24f
    private val elementsStartY = 55f

    private val categoriesTopMargin = 20f
    private val categoriesBottommargin = 20f

    private val xButtonColor = Color(0.2f, 0f, 0f, 1f)

    private var moveDragging = false
    private var resizeDragging = false
    private var splitDragging = false

    private var quad = Pair(0, 0)
    private val resizeArea = 12f
    private var x2 = 0f
    private var y2 = 0f
    private var xHoldOffset = 0f
    private var yHoldOffset = 0f

    private val moveAera
        get() = Rectangle(windowXStart, windowYStart, windowWidth - 20f, 20f)
    private val splitArea
        get() = Rectangle(windowXStart + sideWidth - 5, windowYStart, 10f, windowHeight)

    private var closed = false
    var cant = false
    private var animProgress = 0F

    init {
        ModuleCategory.values().forEach { categoryElements.add(CategoryElement(it)) }
        searchElement = SearchElement(windowXStart + searchXOffset, windowYStart + searchYOffset, searchWidth, searchHeight)
        categoryElements[0].focused = true
    }

    private fun reload() {
        categoryElements.clear()
        ModuleCategory.values().forEach { categoryElements.add(CategoryElement(it)) }

        categoryElements[0].focused = true
    }


    private fun determineQuadrant(mouseX: Int, mouseY: Int): Pair<Int, Int> {
        val result = MutablePair(0, 0)
        val offset2 = 0f
        if (mouseX.toFloat() in windowXStart-resizeArea..windowXStart-offset2) {
            result.left = -1
            xHoldOffset = mouseX - windowXStart
        }
        if (mouseX.toFloat() in windowXEnd+offset2..windowXEnd+resizeArea) {
            result.left = 1
            xHoldOffset = mouseX - windowXEnd
        }
        if (mouseY.toFloat() in windowYStart-resizeArea..windowYStart-offset2) {
            result.right = 1
            yHoldOffset = mouseY - windowYStart
        }
        if (mouseY.toFloat() in windowYEnd+offset2..windowYEnd+resizeArea) {
            result.right = -1
            yHoldOffset = mouseY - windowYEnd
        }
        return result.toPair()
    }

    private fun handleMove(mouseX: Int, mouseY: Int) {
        if (moveDragging) {
            val w = windowWidth
            val h = windowHeight
            windowXStart = mouseX + x2
            windowYStart = mouseY + y2
            windowXEnd = windowXStart + w
            windowYEnd = windowYStart + h
        }
    }

    private fun handleResize(mouseX: Int, mouseY: Int) {
        val mouseX = mouseX - xHoldOffset
        val mouseY = mouseY - yHoldOffset
        if (resizeDragging) {
            val triangleColor = Color(255, 255, 255)
            when (quad.first to quad.second) {
                1 to 1 -> {
                    windowXEnd = mouseX.coerceAtLeast(windowXStart + minWindowWidth)
                    windowYStart = mouseY.coerceAtMost(windowYEnd - minWindowHeight)
                    RenderUtils.drawSquareTriangle(windowXEnd + resizeArea, windowYStart - resizeArea, -resizeArea, resizeArea, triangleColor, true)
                }
                -1 to -1 -> {
                    windowXStart = mouseX.coerceAtMost(windowXEnd - minWindowWidth)
                    windowYEnd = mouseY.coerceAtLeast(windowYStart + minWindowHeight)
                    RenderUtils.drawSquareTriangle(windowXStart - resizeArea, windowYEnd + resizeArea, resizeArea, -resizeArea, triangleColor, true)
                }

                -1 to 1 -> {
                    windowXStart = mouseX.coerceAtMost(windowXEnd - minWindowWidth)
                    windowYStart = mouseY.coerceAtMost(windowYEnd - minWindowHeight)
                    RenderUtils.drawSquareTriangle(windowXStart - resizeArea, windowYStart - resizeArea, resizeArea, resizeArea, triangleColor, true)
                }
                1 to -1 -> {
                    windowXEnd = mouseX.coerceAtLeast(windowXStart + minWindowWidth)
                    windowYEnd = mouseY.coerceAtLeast(windowYStart + minWindowHeight)
                    RenderUtils.drawSquareTriangle(windowXEnd + resizeArea, windowYEnd + resizeArea, -resizeArea, -resizeArea, triangleColor, true)
                }
            }
        }
    }

    private fun resetPositions() {
        windowXStart = 30f
        windowYStart = 30f
        windowXEnd = 500f
        windowYEnd = 400f
        resizeDragging = false
        moveDragging = false
    }

    private fun handleSplit(mouseX: Int) {
        if (splitDragging) {
            sideWidth = (mouseX - windowXStart).coerceIn(80f, windowWidth/2)
        }
    }

    private fun handleMisc() {
        if (Keyboard.isKeyDown(Keyboard.KEY_F12)) {
            resetPositions()
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_F5)) {
            reload()
        }
    }

    override fun initGui() {
        Keyboard.enableRepeatEvents(true)
        categoryElements.forEach { cat ->
            cat.moduleElements.filter { it.listeningKeybind() }.forEach { mod ->
                mod.resetState()
            }
        }

        super.initGui()
    }

    override fun onGuiClosed() {
        categoryElements.filter { it.focused }.map { it.handleMouseRelease(-1, -1, 0, 0f, 0f, 0f, 0f) }
        moveDragging = false
        resizeDragging = false
        splitDragging = false
        closed = false
        animProgress = 0F
        Keyboard.enableRepeatEvents(false)
        CrossSine.fileManager.saveConfigs()
    }

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        animProgress += (0.0075F * 0.25F * RenderUtils.deltaTime * if (closed) -1F else 1F)
        animProgress = animProgress.coerceIn(0F, 1F)
        if (closed && animProgress == 0F) {
            mc.displayGuiScreen(null)
        }
        val percent = EaseUtils.easeOutBack(animProgress.toDouble()).toFloat()
        GL11.glPushMatrix()
        if (!ClickGUIModule.fastRenderValue.get()) {
            GL11.glScalef(percent, percent, percent)
            GL11.glTranslatef(
                ((windowXEnd * 0.5f * (1 - percent)) / percent),
                ((windowYEnd * 0.5f * (1 - percent)) / percent),
                0.0F
            )
        }
        handleMisc()
        handleMove(mouseX, mouseY)
        handleResize(mouseX, mouseY)
        handleSplit(mouseX)
        drawFullSized(mouseX, mouseY, partialTicks, ClientTheme.getColor(1))
        GL11.glPopMatrix()
    }

    private fun drawFullSized(mouseX: Int, mouseY: Int, partialTicks: Float, accentColor: Color, xOffset: Float = 0f, yOffset: Float = 0f) {
        val windowRadius = 5f
        RenderUtils.drawBloomRoundedRect((windowXStart + xOffset), (windowYStart + yOffset), (windowXEnd + xOffset), (windowYEnd + yOffset), windowRadius, 7F, backgroundColor, RenderUtils.ShaderBloom.BOTH)
        if (mouseX.toFloat() in (windowXEnd - 20F)..(windowXEnd) && mouseY.toFloat() in (windowYStart)..(windowYStart + 20F))
            ShaderUtil.drawRoundedRect((windowXEnd + xOffset) - 20f, (windowYStart + yOffset), (windowXEnd + xOffset), (windowYStart + yOffset) + 20f, windowRadius,3F, xButtonColor)
        GlStateManager.disableAlpha()
        RenderUtils.drawImage(IconManager.removeIcon, (windowXEnd + xOffset).toInt() - 15, (windowYStart + yOffset).toInt() + 5, 10, 10)
        RenderUtils.drawImage(IconManager.settings, (windowXStart + xOffset).toInt() + 6, (windowYEnd + yOffset).toInt() - 30, 24,24)
        GlStateManager.enableAlpha()

        searchElement!!.xPos = (windowXStart + xOffset) + searchXOffset
        searchElement!!.yPos = (windowYStart + yOffset) + searchYOffset
        searchElement!!.width = searchWidth

        searchElement!!.searchBox.width = searchWidth.toInt() - 4
        searchElement!!.searchBox.xPosition = ((windowXStart + xOffset) + searchXOffset + 2).toInt()
        searchElement!!.searchBox.yPosition = ((windowYStart + yOffset) + searchYOffset + 2).toInt()

        if (searchElement!!.drawBox(mouseX, mouseY, accentColor)) {
            searchElement!!.drawPanel(mouseX, mouseY, (windowXStart + xOffset) + categoryXOffset, (windowYStart + yOffset) + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin, Mouse.getDWheel(), categoryElements, accentColor)
            return
        }
        RenderUtils.drawBloomRoundedRect((windowXStart + xOffset) + 4f + 8F, startYAnim, (windowXStart + xOffset) + 12f + 8F + stringWidth, endYAnim, 3f, 2.5F, ClientTheme.getColorWithAlpha(0, 190), RenderUtils.ShaderBloom.BOTH)

        var startY = (windowYStart + yOffset) + elementsStartY
        for (ce in categoryElements) {
            ce.drawLabel(mouseX, mouseY, (windowXStart + xOffset), startY, categoryXOffset, elementHeight)
            if (ce.focused) {
                startYAnim = if (ClickGUIModule.fastRenderValue.get())
                    startY + 6f
                             else
                                 AnimationUtils.animate(startY + 6f,
                                    startYAnim,
                                    (if (startYAnim - (startY + 5f) > 0) 0.65f else 0.55f) * RenderUtils.deltaTime * 0.025f
                                )
                endYAnim =  if (ClickGUIModule.fastRenderValue.get())
                                startY + elementHeight - 6f
                            else
                                AnimationUtils.animate(
                                    startY + elementHeight - 6f,
                                    endYAnim,
                                    (if (endYAnim - (startY + elementHeight - 5f) < 0) 0.65f else 0.55f) * RenderUtils.deltaTime * 0.025f
                                )
                ce.drawPanel(mouseX, mouseY, (windowXStart + xOffset) + categoryXOffset, (windowYStart + yOffset) + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin, Mouse.getDWheel(), accentColor)
            }
            startY += elementHeight
            if (ce.name == "Setting" && ce.focused) {
                RenderUtils.drawRoundedRect(windowXStart + 130, windowYStart + 40, windowXEnd - 20, windowYEnd - 20, 4F, Color(20,20,20,255).rgb)
                Fonts.Nova40.drawString("Theme : " , windowXStart + 140, windowYStart + 55, Color.WHITE.rgb, true)
                RenderUtils.drawGradientRoundedRect(windowXStart + 180 + (10 * EaseUtils.easeOutCirc(colorHoveredAnim.toDouble()).toFloat()), windowYStart + 53, windowXStart + 180 + 50 + (10 * EaseUtils.easeOutCirc(colorHoveredAnim.toDouble()).toFloat()), windowYStart + 53 + 12, 5, ClientTheme.getColor(0).rgb, ClientTheme.getColor(180).rgb)
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 185F, windowYStart + 59F, 0F)
                GlStateManager.rotate(90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, colorHoveredAnim)
                GlStateManager.popMatrix()
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 185F + 59.5F, windowYStart + 59F, 0F)
                GlStateManager.rotate(-90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, colorHoveredAnim)
                GlStateManager.popMatrix()
                if (colorHoveredAnim > 0) {
                Fonts.Nova30.drawCenteredString(ClientTheme.ClientColorMode.get(), windowXStart + 180 + 25 + (10 * EaseUtils.easeOutCirc(colorHoveredAnim.toDouble()).toFloat()), windowYStart + 53 + 12 + 4 + 20 - (20 * EaseUtils.easeOutCirc(colorHoveredAnim.toDouble()).toFloat()), Color(255,255,255,(255 * colorHoveredAnim).toInt()).rgb, true)
                }
                colorHoveredAnim = colorHoveredAnim.animSmooth(if (mouseWithinBounds(mouseX, mouseY, windowXStart + 180F, windowYStart + 53F, windowXStart + 180F + 50F + 30F, windowYStart + 53F + 12F)) 1F else -1F, 0.2F)
                colorHoveredAnim = colorHoveredAnim.coerceIn(0F, 1F)

                Fonts.Nova40.drawString("Speed : " , windowXStart + 140, windowYStart + 55 + 15, Color.WHITE.rgb, true)
                Fonts.Nova40.drawString(ClientTheme.fadespeed.get().toString() , windowXStart + 140 + Fonts.Nova40.getStringWidth("Speed : ") + (13 * EaseUtils.easeOutCirc(speedHoveredAnim.toDouble()).toFloat()), windowYStart + 55 + 15, Color.WHITE.rgb, true)
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 180F, windowYStart + 59F + 15, 0F)
                GlStateManager.rotate(90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, speedHoveredAnim)
                GlStateManager.popMatrix()
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 180F + 25F, windowYStart + 59F + 15, 0F)
                GlStateManager.rotate(-90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, speedHoveredAnim)
                GlStateManager.popMatrix()
                speedHoveredAnim = speedHoveredAnim.animSmooth(if (mouseWithinBounds(mouseX, mouseY, windowXStart + 175F, windowYStart + 53F + 15F, windowXStart + 175F + 30F, windowYStart + 53F + 12F + 15F)) 1F else -1F, 0.2F)
                speedHoveredAnim = speedHoveredAnim.coerceIn(0F, 1F)

                Fonts.Nova40.drawString("Index : " , windowXStart + 140, windowYStart + 55 + 30F, Color.WHITE.rgb, true)
                Fonts.Nova40.drawString(ClientTheme.index.get().toString() , windowXStart + 140 + Fonts.Nova40.getStringWidth("Index : ") + (14 * EaseUtils.easeOutCirc(indexHoveredAnim.toDouble()).toFloat()), windowYStart + 55 + 30F, Color.WHITE.rgb, true)
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 175F, windowYStart + 59F + 30F, 0F)
                GlStateManager.rotate(90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, indexHoveredAnim)
                GlStateManager.popMatrix()
                GlStateManager.pushMatrix()
                GlStateManager.translate(windowXStart + 175F + 25F, windowYStart + 59F + 30F, 0F)
                GlStateManager.rotate(-90F, 0F, 0F, 1F)
                RenderUtils.drawImage(ResourceLocation("crosssine/ui/clickgui/expand.png"), -5, -5, 10, 10, indexHoveredAnim)
                GlStateManager.popMatrix()
                indexHoveredAnim = indexHoveredAnim.animSmooth(if (mouseWithinBounds(mouseX, mouseY, windowXStart + 170F, windowYStart + 53F + 30F, windowXStart + 170F + 30F, windowYStart + 53F + 12F + 30F)) 1F else -1F, 0.2F)
                indexHoveredAnim = indexHoveredAnim.coerceIn(0F, 1F)
            }
        }
        for (ce in categoryElements) {
            if (ce.focused) {
                stringWidth = if (ClickGUIModule.fastRenderValue.get()) Fonts.Nova40.getStringWidth(ce.name).toFloat() else
                    AnimationUtils.animate(Fonts.Nova40.getStringWidth(ce.name).toFloat(), stringWidth, 0.55f * RenderUtils.deltaTime * 0.025f)
            }
        }

        super.drawScreen(mouseX, mouseY, partialTicks)
    }

    @Throws(IOException::class)
    override fun mouseClicked(mouseX: Int, mouseY: Int, mouseButton: Int) {
        if (searchElement!!.isTyping() && Rectangle(windowXStart, windowYStart, 60f, 24f).contains(mouseX, mouseY)) {
            searchElement!!.searchBox.text = ""
            return
        }

        if (moveAera.contains(mouseX, mouseY) && !moveDragging) {
            moveDragging = true
            x2 = windowXStart - mouseX
            y2 = windowYStart - mouseY
            return
        }

        if (Rectangle(windowXEnd - 20, windowYStart, 20f, 20f).contains(mouseX, mouseY)) {
            mc.displayGuiScreen(null)
            return
        }
        if (Rectangle(windowXStart, windowYEnd - 40, 40f, 40f).contains(mouseX, mouseY)) {
            mc.displayGuiScreen(GuiClientSettings(this))
            return
        }

        if (splitArea.contains(mouseX, mouseY)) {
            splitDragging = true
            return
        }

        val quad2 = determineQuadrant(mouseX, mouseY)
        if (quad2.first != 0 && quad2.second != 0) {
            quad = quad2
            resizeDragging = true
            return
        }
        for (ce in categoryElements) {
            if (ce.name == "Setting" && ce.focused) {
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 180F, windowYStart + 53F, windowXStart + 180F + 10F, windowYStart + 53F + 10F)) {
                    ClientTheme.ClientColorMode.prevValue()
                }
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 180F + 59F, windowYStart + 53F, windowXStart + 180F + 59F + 10F, windowYStart + 53F + 10F)) {
                    ClientTheme.ClientColorMode.nextValue()
                }
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 175F, windowYStart + 53F + 15F, windowXStart + 175F + 10F, windowYStart + 53F + 10F + 15F) && ClientTheme.fadespeed.get() > 0) {
                    ClientTheme.fadespeed.set(ClientTheme.fadespeed.get() - 1)
                }
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 175F + 25F, windowYStart + 53F + 15F, windowXStart + 175F + 25F + 10F, windowYStart + 53F + 10F + 15F) && ClientTheme.fadespeed.get() < 20) {
                    ClientTheme.fadespeed.set(ClientTheme.fadespeed.get() + 1)
                }
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 170F, windowYStart + 53F + 30F, windowXStart + 170F + 10F, windowYStart + 53F + 10F+ 30F) && ClientTheme.index.get() > 0) {
                    ClientTheme.index.set(ClientTheme.index.get() - 1)
                }
                if (mouseWithinBounds(mouseX, mouseY, windowXStart + 170F + 25F, windowYStart + 53F + 30F, windowXStart + 170F + 25F + 10F, windowYStart + 53F + 10F+ 30F) && ClientTheme.index.get() < 20) {
                    ClientTheme.index.set(ClientTheme.index.get() + 1)
                }
            }
        }

        var startY = windowYStart + elementsStartY

        searchElement!!.handleMouseClick(mouseX, mouseY, mouseButton, windowXStart + categoryXOffset, windowYStart + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin, categoryElements)
        if (!searchElement!!.isTyping()) {
            categoryElements.forEach { cat ->
                if (cat.focused)
                    cat.handleMouseClick(mouseX, mouseY, mouseButton, windowXStart + categoryXOffset, windowYStart + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin)
                if (mouseWithinBounds(mouseX, mouseY, windowXStart, startY, windowXStart + categoryXOffset, startY + elementHeight) && !searchElement!!.isTyping()) {
                    categoryElements.forEach(Consumer { e: CategoryElement -> e.focused = false })
                    cat.focused = true
                    return
                }
                startY += elementHeight
            }
        }
    }

    override fun mouseReleased(mouseX: Int, mouseY: Int, state: Int) {
        if (moveDragging && moveAera.contains(mouseX, mouseY)) {
            moveDragging = false
            return
        }

        if (resizeDragging)
            resizeDragging = false

        if (splitDragging)
            splitDragging = false

        searchElement!!.handleMouseRelease(mouseX, mouseY, state, windowXStart + categoryXOffset, windowYStart + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin, categoryElements)
        if (!searchElement!!.isTyping()) {
            categoryElements.filter { it.focused }.forEach { cat ->
                cat.handleMouseRelease(mouseX, mouseY, state, windowXStart + categoryXOffset, windowYStart + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin)
            }
        }
        super.mouseReleased(mouseX, mouseY, state)
    }

    @Throws(IOException::class)
    override fun keyTyped(typedChar: Char, keyCode: Int) {
        if (keyCode == 1 && !cant) {
            closed = true
            if (ClickGUIModule.fastRenderValue.get())   mc.displayGuiScreen(null)
            return
        }
        categoryElements.filter { it.focused }.forEach { cat ->
            if (cat.handleKeyTyped(typedChar, keyCode)) return
        }
        if (searchElement!!.handleTyping(typedChar, keyCode, windowXStart + categoryXOffset, windowYStart + categoriesTopMargin, windowWidth - categoryXOffset, windowHeight - categoriesBottommargin, categoryElements))
            return
        super.keyTyped(typedChar, keyCode)
    }

    override fun doesGuiPauseGame(): Boolean {
        return false
    }

    companion object {
        private var instance: ClickGui? = null
        fun getInstance(): ClickGui {
            return if (instance == null) ClickGui().also { instance = it } else instance!!
        }

        fun resetInstance() {
            instance = ClickGui()
        }
    }
}
